from lxml import etree
import requests
import os
#需求：王清源想看美女 https://pic.netbian.com/4kmeinv/

def get_meinv(num, url='https://pic.netbian.com/4kmeinv/'):
        if num > 1:
            url = 'https://pic.netbian.com/4kmeinv/index_' + str(num) + '.html'
        response = requests.get(url=url,headers=headers)
        response.encoding = 'gbk'
        page_text = response.text
        tree = etree.HTML(page_text)
        li_list = tree.xpath('/html/body/div[@class="wrap clearfix"]//li')
        for i in li_list:
            wangzhi = 'https://pic.netbian.com' + i.xpath('./a/img/@src')[0]
            meinv_name = i.xpath('./a/img/@alt')[0] + '.jpg'
            meinv_data = requests.get(url=wangzhi,headers=headers).content
            meinv_path = 'meinv/' + meinv_name
            with open(meinv_path,'wb') as fp:
                fp.write(meinv_data)
                print(meinv_name,'下载成功！! !')

if __name__ == "__main__":
    num = int(input('你想看几页(别超过68): '))
    headers = {'User-Agent':
               'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'}
    if not os.path.exists('./meinv'):
        os.mkdir('./meinv')
    if num < 1:
        print('别搞')
    for i in range(num):
         get_meinv(i+1)